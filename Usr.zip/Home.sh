clear
echo ""
echo ""
echo ""
echo ""
cd /data/data/com.termux/files/home/

neofetch
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""
echo ""